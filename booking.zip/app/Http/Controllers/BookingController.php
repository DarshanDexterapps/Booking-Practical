<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function showForm()
    {
        return view('booking.form');
    }

public function store(Request $request)
{
    $request->validate([
        'customer_name' => 'required|string|max:255',
        'customer_email' => 'required|email|max:255',
        'booking_date' => 'required|date',
        'booking_type' => 'required|in:full_day,half_day,custom',
        'booking_slot' => [
            function ($attribute, $value, $fail) use ($request) {
                if ($request->booking_type === 'half_day' && !$value) {
                    $fail('The booking slot is required for half-day bookings.');
                }
            },
        ],
        'booking_from' => 'nullable|date_format:H:i',
        'booking_to' => 'nullable|date_format:H:i|after:booking_from',
    ]);

    $bookingDate = $request->booking_date;
    $bookingType = $request->booking_type;
    $bookingSlot = $request->booking_slot;
    $bookingFrom = $request->booking_from;
    $bookingTo = $request->booking_to;

    $fullDayExists = Booking::where('booking_date', $bookingDate)
                            ->where('booking_type', 'full_day')
                            ->exists();

    if ($fullDayExists) {
        return redirect()->back()->with('error', 'Full day is already booked on this date.');
    }

    if ($bookingType === 'half_day') {
        $halfDayExists = Booking::where('booking_date', $bookingDate)
                                ->where('booking_type', 'half_day')
                                ->where('booking_slot', $bookingSlot)
                                ->exists();

        if ($halfDayExists) {
            return redirect()->back()->with('error', "This half-day slot is already booked on this date.");
        }

        $existingHalfDay = Booking::where('booking_date', $bookingDate)
                                  ->where('booking_type', 'half_day')
                                  ->exists();

        if ($existingHalfDay) {
            return redirect()->back()->with('error', 'Full-day booking is not allowed as a half-day is already booked.');
        }
    }

    if ($bookingType === 'custom') {
        $customExists = Booking::where('booking_date', $bookingDate)
            ->where(function ($query) use ($bookingFrom, $bookingTo) {
                $query->where(function ($q) use ($bookingFrom, $bookingTo) {
                    $q->where('start_time', '<', $bookingTo)
                      ->where('end_time', '>', $bookingFrom);
                });
            })->exists();

        if ($customExists) {
            return redirect()->back()->with('error', "A booking already exists in this time range.");
        }

        $morningExists = Booking::where('booking_date', $bookingDate)
            ->where('booking_type', 'custom')
            ->where('start_time', '<', '12:00')
            ->exists();

        if ($morningExists && ($bookingType === 'full_day' || ($bookingType === 'half_day' && $bookingSlot === 'first_half'))) {
            return redirect()->back()->with('error', "A custom booking in the morning exists. You cannot book full day or first half.");
        }
    }

    Booking::create([
        'user_id' => auth()->id(),
        'booking_date' => $bookingDate,
        'booking_type' => $bookingType,
        'booking_slot' => $bookingType === 'half_day' ? $bookingSlot : null,
        'start_time' => $bookingType === 'custom' ? $bookingFrom : null,
        'end_time' => $bookingType === 'custom' ? $bookingTo : null,
    ]);

    return redirect()->back()->with('success', 'Booking successfully submitted!');
}

}