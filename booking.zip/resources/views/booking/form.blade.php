@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Booking Form') }}</div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('booking.store') }}">
                        @csrf

                        <div class="mb-3">
                            <label for="customer_name" class="form-label">{{ __('Customer Name') }}</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name" value="{{ old('customer_name') }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="customer_email" class="form-label">{{ __('Customer Email') }}</label>
                            <input type="email" class="form-control" id="customer_email" name="customer_email" value="{{ old('customer_email') }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="booking_date" class="form-label">{{ __('Booking Date') }}</label>
                            <input type="date" class="form-control" id="booking_date" name="booking_date" value="{{ old('booking_date') }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="booking_type" class="form-label">{{ __('Booking Type') }}</label>
                            <select class="form-control" id="booking_type" name="booking_type" required onchange="toggleFields()">
                                <option value="full_day" {{ old('booking_type') == 'full_day' ? 'selected' : '' }}>Full Day</option>
                                <option value="half_day" {{ old('booking_type') == 'half_day' ? 'selected' : '' }}>Half Day</option>
                                <option value="custom" {{ old('booking_type') == 'custom' ? 'selected' : '' }}>Custom</option>
                            </select>
                        </div>

                        <div class="mb-3 {{ old('booking_type') == 'half_day' ? '' : 'd-none' }}" id="slot_section">
                            <label for="booking_slot" class="form-label">{{ __('Booking Slot') }}</label>
                            <select class="form-control" id="booking_slot" name="booking_slot">
                                <option value="first_half" {{ old('booking_slot') == 'first_half' ? 'selected' : '' }}>First Half</option>
                                <option value="second_half" {{ old('booking_slot') == 'second_half' ? 'selected' : '' }}>Second Half</option>
                            </select>
                        </div>

                        <!-- Hidden input to prevent validation errors when half_day is not selected -->
                        <input type="hidden" id="hidden_booking_slot" name="booking_slot" value="">

                        <div class="mb-3 {{ old('booking_type') == 'custom' ? '' : 'd-none' }}" id="time_section">
                            <label for="booking_from" class="form-label">{{ __('Booking From') }}</label>
                            <input type="time" class="form-control" id="booking_from" name="booking_from" value="{{ old('booking_from') }}">

                            <label for="booking_to" class="form-label mt-2">{{ __('Booking To') }}</label>
                            <input type="time" class="form-control" id="booking_to" name="booking_to" value="{{ old('booking_to') }}">
                        </div>

                        <button type="submit" class="btn btn-primary">Submit Booking</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleFields() {
        let bookingType = document.getElementById('booking_type').value;
        let slotSection = document.getElementById('slot_section');
        let timeSection = document.getElementById('time_section');
        let bookingSlot = document.getElementById('booking_slot');
        let bookingFrom = document.getElementById('booking_from');
        let bookingTo = document.getElementById('booking_to');

        if (bookingType === 'half_day') {
            slotSection.classList.remove('d-none');
        } else {
            slotSection.classList.add('d-none');
            bookingSlot.value = ''; 
        }

        if (bookingType === 'custom') {
            timeSection.classList.remove('d-none');
        } else {
            timeSection.classList.add('d-none');
            bookingFrom.value = ''; 
            bookingTo.value = '';
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        toggleFields();
    });
</script>
@endsection